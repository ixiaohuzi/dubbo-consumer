package com.yihu.dubbo.consumer;/*
 * Copyright (C) 1997-2020 康成投资（中国）有限公司
 *
 * http://www.rt-mart.com
 *
 * 版权归本公司所有，不得私自使用、拷贝、修改、删除，否则视为侵权
 */

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Program arguments:  --server.port=80
 */

/**
 * SpringBootApplication：基础启动注解
 * scanBasePackages：指定路径扫描为bean，支持配置jar包目录
 * exclude：排除指定类（Test.class）
 * 注意：exclude只能排除auto-configuration类型的类
 */
@SpringBootApplication(scanBasePackages = {"com.yihu"}, exclude = {})
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

}