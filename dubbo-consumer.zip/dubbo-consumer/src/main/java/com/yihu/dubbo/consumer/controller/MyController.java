package com.yihu.dubbo.consumer.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class MyController {

    @DubboReference(version = "1.0.0")
    private MyDubboService myDubboService;

    @GetMapping("/callServiceA")
    public String callServiceA() {
        return myDubboService.sayHello("Hello from Service B");
    }
}